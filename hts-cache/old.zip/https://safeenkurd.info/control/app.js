$(document).ready(function () {
    $('.preloader').hide();
});